﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DependencyInjectionExample.Models
{
    public interface IEmployeeRepo
    {
        /// <summary>
        /// function for getting employee by id.
        /// </summary>
        /// <param name="id">employee id</param>
        /// <returns>returns employee by id</returns>
        Employee GetEmployee(int id);
    }
}
