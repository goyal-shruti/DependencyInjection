﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DependencyInjectionExample.Models
{
    public class MockEmployeeRepository : IEmployeeRepo
    {
        private List<Employee> _employeeList { get; set; }

        public MockEmployeeRepository()
        {
            // Create mock employee data
            _employeeList = new List<Employee>()
            {
                new Employee(){Id=1,Name="Shruti",Department="CS",Email="xyz.gmail.com"},
                new Employee(){Id=2,Name="Ankit",Department="Accounts",Email="abc.gmail.com"},
                new Employee(){Id=3,Name="Atharva",Department="Science",Email="pwc.gmail.com"},
                new Employee(){Id=4,Name="Ashu",Department="Maths",Email="lmn.gmail.com"},
            };
        }

        /// <summary>
        /// function for getting employee by id.
        /// </summary>
        /// <param name="id">employee id</param>
        /// <returns>returns employee by id</returns>
        public Employee GetEmployee(int id)
        {
           return _employeeList.Find(e => e.Id == id);
        }
    }
}
